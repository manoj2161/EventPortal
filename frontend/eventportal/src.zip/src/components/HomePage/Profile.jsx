import { useState } from "react";
import { Header } from "./Header";
import { ProfileDetailsCard } from "./ProfileDetailsCard";
import { ProfileDetailsSection } from "./ProfileDetailsSection";
import { ProfileEditModel } from "./ProfileEditModel";

export const Profile = () => {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <Header />
      <div className="relative">
        <ProfileDetailsSection visible={visible} setVisible={setVisible} />
        <ProfileDetailsCard />
        <div className="absolute top-0 z-100">
         <ProfileEditModel visible={visible} />
        </div>
      </div>
    </>
  );
};
